/** Automatically generated file. DO NOT MODIFY */
package com.android_examples.com.tabhost;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}