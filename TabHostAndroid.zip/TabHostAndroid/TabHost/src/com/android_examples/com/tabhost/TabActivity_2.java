package com.android_examples.com.tabhost;

import android.app.Activity;
import android.os.Bundle;

public class TabActivity_2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_activity_2);
	}
}
